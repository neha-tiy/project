import { Component, OnInit } from '@angular/core';
import { ProductInfo } from '../product-info';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
	id:number;
	product:ProductInfo;

  constructor(private route:ActivatedRoute,private router: Router,
  	private loginService:LoginService) { }

  ngOnInit() {
    this.product=new ProductInfo();
    this.id=this.route.snapshot.params['id'];
    this.loginService.getProductUpdate(this.id)
    .subscribe(data=>{
      console.log(data)
      this.product=data;
    },
    error=>console.log(error));
  }

  updateEmployee(){
    this.loginService.updateProduct(this.id,this.product)
    .subscribe(data=>console.log(data),
      error=>console.log(error));
    this.product=new ProductInfo();
    this.gotoList();
  }
  onSubmit(){
    this.updateEmployee();
  }
  gotoList(){
    this.router.navigate(['/product']);
  }

}
