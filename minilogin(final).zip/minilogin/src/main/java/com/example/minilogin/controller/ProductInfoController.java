package com.example.minilogin.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.minilogin.DAO.ProductInfoDAO;
import com.example.minilogin.model.ProductInfo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProductInfoController {
	
	@Autowired
	private ProductInfoDAO productDao;
	
	@GetMapping("/product")
	public List getProducts() {	
	return productDao.viewAllProductInfo();
}

	
	@PostMapping("/productadd")
	public ResponseEntity addProductInfo(@RequestBody ProductInfo product) {
		System.out.println("hello......");
		productDao.addProductInfo(product);
		return new ResponseEntity(product, HttpStatus.OK);
	}
	@PutMapping("/product/{product_id}")
	public ResponseEntity<ProductInfo> updateProductInfo1(@PathVariable(value="product_id") String ProductInfoId, @Valid @RequestBody ProductInfo productDetails) {
		 productDetails.setProduct_id(productDetails.getProduct_id());
		 productDetails.setCategory_type(productDetails.getCategory_type());
		 productDetails.setProduct_description(productDetails.getProduct_description());
		 productDetails.setProduct_icon(productDetails.getProduct_icon());
		 productDetails.setProduct_name(productDetails.getProduct_name());
		 productDetails.setProduct_price(productDetails.getProduct_price());
		 productDetails.setProduct_status(productDetails.getProduct_status());
		 productDetails.setProduct_stock(productDetails.getProduct_stock());
		productDao.updateProductInfo(ProductInfoId, productDetails);
				return new ResponseEntity(productDetails, HttpStatus.OK);		
	}
	@DeleteMapping("/product/{product_id}")
	public ResponseEntity<ProductInfo> deleteProductInfo1(@PathVariable (value="product_id") String ProductInfoId) {
		productDao.deleteProductInfo(ProductInfoId);
		System.out.println("Deleted");
				return new ResponseEntity(ProductInfoId,HttpStatus.OK);		
	}
	/*
	 * public Map<String,Boolean> deleteProductInfo(@PathVariable(value="id") Long
	 * ProductInfoId) throws ResourceNotFoundException{ ProductInfo
	 * ProductInfo=ProductInfoRepository.findById(ProductInfoId) .orElseThrow(() ->
	 * new ResourceNotFoundException("ProductInfo not found for this id ::"
	 * +ProductInfoId)); ProductInfoRepository.delete(ProductInfo);
	 * Map<String,Boolean> response=new HashMap<>();
	 * response.put("deleted",Boolean.TRUE); return response; }
	 */
}
